title: 内网穿frp
date: '2019-09-12 01:06:40'
updated: '2019-09-12 01:06:40'
tags: [待分类]
permalink: /articles/2019/09/12/1568221600679.html
---
![](https://img.hacpai.com/bing/20190127.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 使用场景

* teamviwer不经过teamviwer官方服务器，不会有激活限�?* 内网服务器需要外网访�?* 手机作为主服务器，经过腾讯云服务器提供外网支�?
## frp介绍
* github地址: https://github.com/fatedier/frp
* 软件包地址: https://github.com/fatedier/frp/releases

## 配置启动

### 服务端（腾讯云）
#### vi frps.ini
```
[common]
bind_port = 7000
```
#### 启动
```
nohup ./frps -c ./frps.ini &
```
### 客户端（内网机）

#### vi frpc.ini
```
[common]
server_addr = noner.cn
server_port = 7000
admin_addr = 0.0.0.0
admin_port = 7400
admin_user = username
admin_pwd = password

[ssh]
type = tcp
local_port = 22
remote_port = 2222
use_encryption = true
use_compression = true
```
#### 启动
```
nohup ./frpc -c ./frpc.ini &
```

## 使用
### 管理页面
http://客户端ip:7400
![捕获.PNG](https://img.hacpai.com/file/2019/09/捕获-eae99427.PNG)


