title: apollo配置中心
date: '2019-09-12 00:39:32'
updated: '2019-09-12 00:40:40'
tags: [待分类]
permalink: /articles/2019/09/12/1568219972729.html
---
![](https://img.hacpai.com/bing/20180614.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 介绍
> https://github.com/ctripcorp/apollo

基于mysql的配置中�?local 本地开发环�?dev 开发环�?fat 功能验收测试环境
uat 用户验收测试环境(演示环境)
lpt 抗压测试环境
pro 生产环境

### 安装

#### docker方式
> 参考：https://github.com/idoop/docker-apollo

docker 加�?
```
curl -sSL https://get.daocloud.io/daotools/set_mirror.sh | sh -s http://f1361db2.m.daocloud.io
vim /etc/docker/daemen.json 删除多余逗号
systemctl restart docker
```

docker-compose

```
sudo yum install epel-release -y
sudo yum install -y python-pip
sudo pip install docker-compose
docker-compose up
```

mysql

```
- 创建ApolloPortalDB,ApolloConfigDBDev,ApolloConfigDBFat
- 导入sql文件
- 下载地址:http://note.youdao.com/noteshare?id=3b232bb91bd5e39ab2d4e27c7498b5f0&sub=98F24DE9B45348DA98F1E1393EBE102A
- 修改ServerConfig表中 apollo.portal.envs和eureka.service.url 数据
```

docker-compose.yaml
```
version: '2.2'
services:
  apollo:
    image: idoop/docker-apollo:latest
    network_mode: "host"
    environment:
      # 开启Portal,默认端口: 8070
      PORTAL_DB: jdbc:mysql://mysql:3306/ApolloPortalDB?characterEncoding=utf8
      PORTAL_DB_USER: root
      PORTAL_DB_PWD: password

      # 开启dev环境, 默认端口: config 18080, admin 18090
      DEV_DB: jdbc:mysql://mysql:3306/ApolloConfigDBDev?characterEncoding=utf8
      DEV_DB_USER: root
      DEV_DB_PWD: password
      DEV_CONFIG_PORT: 18080
      DEV_ADMIN_PORT: 18090

      # 开启fat环境, 默认端口: config 18081, admin 18091
      FAT_DB: jdbc:mysql://mysql:3306/ApolloConfigDBFat?characterEncoding=utf8
      FAT_DB_USER: root
      FAT_DB_PWD: password
      FAT_CONFIG_PORT: 18081
      FAT_ADMIN_PORT: 18091

```

#### jar方式

> 参考文档：https://github.com/ctripcorp/apollo/wiki/%E5%88%86%E5%B8%83%E5%BC%8F%E9%83%A8%E7%BD%B2%E6%8C%87%E5%8D%97

Apollo v1.4.0 Release版本
```
jar包下载路�?http://note.youdao.com/noteshare?id=7157b72d2213478f6e50531521f9c3a4&sub=72CCC1D7E236497EBDCA3C4A1DF7D2BA
```

sql导入

修改配置信息

```
config/application-github.properties
mysql连接信息
apollo-portal-1.4.0-github/config/apollo-env.properties
各环境config连接地址
```
启动

```
nohup java -jar config &
nohup java -jar admin &
nohup java -jar portal &
```

### 使用
初始用户�?密码 apollo/admin
![新增项目,应用id与项目名一致](https://img-blog.csdnimg.cn/20190820175739445.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl8zNTkyODIwOA==,size_16,color_FFFFFF,t_70)
![修改配置](https://img-blog.csdnimg.cn/20190820175821244.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl8zNTkyODIwOA==,size_16,color_FFFFFF,t_70)

```
yml转Properties 地址：https://www.toyaml.com/index.html
```

### 集成spring cloud
![集成代码](https://img-blog.csdnimg.cn/20190820185915710.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3dlaXhpbl8zNTkyODIwOA==,size_16,color_FFFFFF,t_70)
