title: 安卓手机-centos7服务
date: '2019-09-12 01:22:56'
updated: '2019-09-12 01:23:21'
tags: [待分类]
permalink: /articles/2019/09/12/1568222576685.html
---
![](https://img.hacpai.com/bing/20180831.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 介绍
### 背景
* 由于手上闲置一台小米note3手机
* 内存6g,8�?* Android系统
* 有一台最低配腾讯云服务器，软件内存占用一大，就杀进程

所以实践了在手机上安装centos7 系统，再通过腾讯云服务器转发，废物利用�?### 该方案已知缺�?* 手机需要一直接上电�?* 手机上传下载速度都取决于服务器带�?* 手机模拟centos7为chroot模式，不能使用docker,systemctl等命令（mysql,redis,nginx等需要命令行启动,不能使用systemctl�?* centos 7为aarch64架构
![捕获2.PNG](https://img.hacpai.com/file/2019/09/捕获2-636fd508.PNG)
* 端口查看需要加上过滤，包含Android端口进程
![捕获3.PNG](https://img.hacpai.com/file/2019/09/捕获3-b5123cf3.PNG)
## 操作步骤
待补�?..
